"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Marca = (function () {
    function Marca() {
    }
    return Marca;
}());
exports.Marca = Marca;
//# sourceMappingURL=marca.js.map