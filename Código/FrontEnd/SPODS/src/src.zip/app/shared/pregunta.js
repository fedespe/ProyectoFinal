"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Pregunta = (function () {
    function Pregunta() {
    }
    return Pregunta;
}());
exports.Pregunta = Pregunta;
//# sourceMappingURL=pregunta.js.map