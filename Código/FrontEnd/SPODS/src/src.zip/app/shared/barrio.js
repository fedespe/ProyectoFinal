"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Barrio = (function () {
    function Barrio() {
    }
    return Barrio;
}());
exports.Barrio = Barrio;
//# sourceMappingURL=barrio.js.map