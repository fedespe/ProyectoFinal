import { Departamento } from '../shared/departamento';

export class Barrio {
    Id: number;
    Nombre: string;
    Departamento: Departamento;
}