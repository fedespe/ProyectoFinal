"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var pregunta_1 = require("./pregunta");
var Respuesta = (function () {
    function Respuesta() {
        this.Pregunta = new pregunta_1.Pregunta();
    }
    return Respuesta;
}());
exports.Respuesta = Respuesta;
//# sourceMappingURL=respuesta.js.map