import { Utilidades } from "./utilidades";

export class CategoriaPregunta {
    Id: number;
    Categoria:string;
    

    constructor() {      
       
    }
}