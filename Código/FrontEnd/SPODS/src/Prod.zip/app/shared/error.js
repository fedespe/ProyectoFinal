"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Error = (function () {
    function Error() {
    }
    return Error;
}());
exports.Error = Error;
//# sourceMappingURL=error.js.map