"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Exito = (function () {
    function Exito() {
    }
    return Exito;
}());
exports.Exito = Exito;
//# sourceMappingURL=exito.js.map