import { Utilidades } from "./utilidades";
import { CategoriaPregunta } from "./categoriaPregunta";
import { Respuesta } from "./respuesta";

export class Pregunta {
    Id: number;
    UnaPregunta:string;
    Categoria:CategoriaPregunta;
    UnaRespuesta:string;
    

    constructor() {      
       
    }
}