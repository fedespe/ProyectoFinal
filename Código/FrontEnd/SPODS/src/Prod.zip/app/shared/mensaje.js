"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Mensaje = (function () {
    function Mensaje() {
        this.Errores = [];
        this.Exitos = [];
    }
    return Mensaje;
}());
exports.Mensaje = Mensaje;
//# sourceMappingURL=mensaje.js.map