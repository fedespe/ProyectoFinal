"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Servicio = (function () {
    function Servicio() {
        this.Preguntas = [];
        // this.Barrio = new Barrio();
        // this.Barrio.Id=0;
    }
    return Servicio;
}());
exports.Servicio = Servicio;
//# sourceMappingURL=servicio.js.map