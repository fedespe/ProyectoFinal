export class Error {
    Descripcion: string;
}