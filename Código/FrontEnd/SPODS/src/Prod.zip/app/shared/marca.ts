export class Marca {
    Id: number;
    Nombre: string;
}