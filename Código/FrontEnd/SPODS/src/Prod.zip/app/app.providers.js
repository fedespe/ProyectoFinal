"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var data_service_1 = require("./shared/services/data.service");
exports.APP_PROVIDERS = [
    data_service_1.DataService
];
//# sourceMappingURL=app.providers.js.map