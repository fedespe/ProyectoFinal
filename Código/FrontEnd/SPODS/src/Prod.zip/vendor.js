"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
require("rxjs");
require("core-js");
require("ng2-translate");
require("zone.js/dist/zone");
require("@angular/common");
require("@angular/compiler");
require("@angular/core");
require("@angular/forms");
require("@angular/http");
require("@angular/platform-browser");
require("@angular/platform-browser-dynamic");
require("@angular/router");
//# sourceMappingURL=vendor.js.map