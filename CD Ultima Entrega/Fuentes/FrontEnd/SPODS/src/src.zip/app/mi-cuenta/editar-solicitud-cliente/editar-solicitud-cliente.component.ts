import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from '../../shared/services/data.service';
import { Utilidades } from "../../shared/utilidades";
import { Mensaje } from "../../shared/mensaje";
import { Error } from "../../shared/error";
import { Exito } from "../../shared/exito";
import { Servicio } from "../../shared/servicio";
import { Settings } from "../../shared/settings";
import { Publicacion } from "../../shared/publicacion";
import { Respuesta } from "../../shared/respuesta";
import { ActivatedRoute } from '@angular/router';  


@Component({
    selector: 'editar-solicitud-cliente',
    templateUrl: 'app/mi-cuenta/editar-solicitud-cliente/editar-solicitud-cliente.component.html',
    styleUrls:  ['css/editar-solicitud-cliente.css']
})

export class EditarSolicitudClienteComponent implements OnInit{
    mensajes: Mensaje = new Mensaje();
    loading = true;
    servicios: Servicio[] = [];
    publicacion: Publicacion = new Publicacion();
    servicioSeleccionado: Servicio = new Servicio();
    respuestas: string[] = [];
    idPublicacion:number;
    step:number=1;
    urlImagen:string=Settings.srcImg+"/Oferta/IngresarImagenes";

    constructor(private dataService: DataService, private router: Router,private route: ActivatedRoute) {
    }
    ngOnInit() {
        // subscripción al observable params
        this.route.params
        .subscribe(params => {
            this.idPublicacion = parseInt(params['id']);
            Utilidades.log("[editar-solicitud-cliente.component.ts] - ngOnInit | idPublicacion: " + JSON.stringify(this.idPublicacion));   
        });
        this.obtenerPublicacion();       
    }
    borrarMensajes(){
        this.mensajes.Errores = [];
        this.mensajes.Exitos = [];
    }
    obtenerPublicacion(){
        Utilidades.log("[editar-solicitud-cliente.component.ts] - obtenerPublicacion | idPublicacion: " + JSON.stringify(this.idPublicacion));
       this.dataService.getPublicacion(this.idPublicacion)
           .subscribe(
           res => this.getPublicacionOk(res),
           error => this.getPublicacionError(error),
           () => Utilidades.log("[editar-solicitud-cliente.component.ts] - getPublicacion: Completado")
       );
   }
   getPublicacionOk(response:any){
       Utilidades.log("[editar-solicitud-cliente.component.ts] - getPublicacionOk | response: " + JSON.stringify(response));       
       if(response.Codigo ==  200){
           this.publicacion = response.Objetos[0]; 
           document.getElementById('inputIdPublicacion').setAttribute('value',this.publicacion.Id.toString());
           document.getElementById('mostrarImagenes').click();         
           this.obtenerServicio(this.publicacion.Servicio.Id);
       }
       else{
           var error = new Error();
           error.Descripcion = response.Mensaje;           
           this.mensajes.Errores.push(error);
           this.loading = false;
       }
   }
   getPublicacionError(responseError:any){
       Utilidades.log("[editar-solicitud-cliente.component.ts] - getPublicacionError | responseError: " + JSON.stringify(responseError));
       var error = new Error();
       error.Descripcion = "Ha ocurrido un error inesperado. Contacte al administrador.";
       this.mensajes.Errores.push(error);
       this.loading = false;
   }
   obtenerServicio(id:number){
    this.dataService.getObtenerServicio(id)
        .subscribe(
            res => this.getObtenerServicioOk(res),
            error => this.getObtenerServicioError(error),
            () => Utilidades.log("[editar-solicitud-cliente.component.ts] - getObtenerServicio: Completado")
        );
    }
    getObtenerServicioOk(response:any){
        
        Utilidades.log("[editar-solicitud-cliente.component.ts] - getObtenerServicioOk | response: " + JSON.stringify(this.servicioSeleccionado));
        if(response.Codigo ==  200){
            this.publicacion.Servicio = response.Objetos[0];
            this.responderPreguntas();//metodo que completa en alngular las respuestas a las preguntas
        }
        else{
            var error = new Error();
            error.Descripcion = response.Mensaje;           
            this.mensajes.Errores.push(error);
            this.loading = false;
        }
    }
    getObtenerServicioError(responseError:any){
        Utilidades.log("[editar-solicitud-cliente.component.ts] - getObtenerServicioError | responseError: " + JSON.stringify(responseError));
        var error = new Error();
        error.Descripcion = "Ha ocurrido un error inesperado. Contacte al administrador.";
        this.mensajes.Errores.push(error);
        this.loading = false;
    }
    responderPreguntas(){
        for (var i = 0; i < this.publicacion.Respuestas.length; i++) {
            for (var j = 0; j < this.publicacion.Servicio.Preguntas.length; j++) {
                if(this.publicacion.Servicio.Preguntas[j].Id==this.publicacion.Respuestas[i].Pregunta.Id){
                    this.publicacion.Servicio.Preguntas[j].UnaRespuesta=this.publicacion.Respuestas[i].UnaRespuesta;
                }         
            }                
        } 
        this.loading = false;
    }
    editarServicioPaso1(){
        this.borrarMensajes();
        //Cuando se trae la publicacion por servcio no deja usar la funcion this.publicacion.validarDatos()
        //Se crea una nueva publicacion para hacer la validacion
        var p = new Publicacion();
        p.Titulo=this.publicacion.Titulo;
        p.Servicio=this.publicacion.Servicio;
        p.Descripcion=this.publicacion.Descripcion;
        /*if(this.publicacion.Descripcion == null || this.publicacion.Descripcion.trim() == ""){
            this.publicacion.Descripcion = "Sin descripción.";
        }*/
        this.mensajes.Errores = p.validarDatos1();
        this.publicacion.Descripcion = p.Descripcion;
        //fin validacion
        if(this.mensajes.Errores.length == 0){
            this.step=2;
        }    
    }
    editarServicioPaso2(){
        this.putActualizarPublicacion();       
    }
    volverPaso1(){
        this.step=1;
    }
    editarServicioPaso3(){
        var exito = new Exito();
        exito.Descripcion = "La publicación ha sido actualizada con éxito";           
        this.mensajes.Exitos.push(exito);
        this.step=1;
    }
    putActualizarPublicacion(){
        Utilidades.log("[editar-solicitud-cliente.component.ts] - putActualizarPublicacion | respuestas: " + JSON.stringify(this.respuestas));
        this.borrarMensajes();
        //Cuando se trae la publicacion por servcio no deja usar la funcion this.publicacion.validarDatos()
        //Se crea una nueva publicacion para hacer la validacion
        var p = new Publicacion();
        p.Titulo=this.publicacion.Titulo;
        p.Imagenes=this.publicacion.Imagenes;
        p.Servicio=this.publicacion.Servicio;
        p.Descripcion=this.publicacion.Descripcion;
        this.mensajes.Errores = p.validarDatos();
        //fin validacion
        this.publicacion.Respuestas=[];
        if(this.mensajes.Errores.length==0){
            for (var i = 0; i < this.publicacion.Servicio.Preguntas.length; i++) {
                if(this.publicacion.Servicio.Preguntas[i].UnaRespuesta!=null && this.publicacion.Servicio.Preguntas[i].UnaRespuesta!=""){
                    var r = new Respuesta();
                    r.Pregunta.Id=this.publicacion.Servicio.Preguntas[i].Id;
                    r.UnaRespuesta=this.publicacion.Servicio.Preguntas[i].UnaRespuesta;
                    this.publicacion.Respuestas.push(r);
                }              
            } 
            Utilidades.log("[editar-solicitud-cliente.component.ts] - putActualizarPublicacion | publicacion: " + JSON.stringify(this.publicacion));
            this.dataService.putActualizarPublicacion(this.publicacion)
                .subscribe(
                res => this.putActualizarPublicacionOk(res),
                error => this.putActualizarPublicacionError(error),
                () => Utilidades.log("[editar-solicitud-cliente.component.ts] - putActualizarPublicacion: Completado")
            );
        }
    }
    putActualizarPublicacionOk(response:any){       
        Utilidades.log("[editar-solicitud-cliente.component.ts] - putActualizarPublicacionOK | response: " + JSON.stringify(this.servicioSeleccionado));
        if(response.Codigo ==  200){
            this.step=3;
        }
        else{
            var error = new Error();
            error.Descripcion = response.Mensaje;           
            this.mensajes.Errores.push(error);
        }
    }
    putActualizarPublicacionError(responseError:any){
        Utilidades.log("[editar-solicitud-cliente.component.ts] - putActualizarPublicacionError | responseError: " + JSON.stringify(responseError));
        var error = new Error();
        error.Descripcion = "Ha ocurrido un error inesperado. Contacte al administrador.";
        this.mensajes.Errores.push(error);
    }
}