import { Utilidades } from "./utilidades";
import { Pregunta } from "./pregunta";

export class Respuesta {
    UnaRespuesta: string;
    Pregunta: Pregunta=new Pregunta();

    

    constructor() {      

    }
}