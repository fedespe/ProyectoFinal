"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var CategoriaPregunta = (function () {
    function CategoriaPregunta() {
    }
    return CategoriaPregunta;
}());
exports.CategoriaPregunta = CategoriaPregunta;
//# sourceMappingURL=categoriaPregunta.js.map