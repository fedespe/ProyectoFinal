export class Departamento {
    Id: number;
    Nombre: string;
}