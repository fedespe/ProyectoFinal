import {Error} from "./error";
import {Exito} from "./exito";

export class Mensaje {
    Errores: Error[] = [];
    Exitos: Exito[] = [];
}