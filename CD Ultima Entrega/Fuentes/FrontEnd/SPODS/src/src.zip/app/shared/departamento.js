"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Departamento = (function () {
    function Departamento() {
    }
    return Departamento;
}());
exports.Departamento = Departamento;
//# sourceMappingURL=departamento.js.map