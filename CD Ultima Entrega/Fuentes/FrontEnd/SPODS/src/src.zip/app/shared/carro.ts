import { Marca } from "./marca";

export class Carro {
    Id: number;
    Marca: Marca;
    Modelo: number;
}