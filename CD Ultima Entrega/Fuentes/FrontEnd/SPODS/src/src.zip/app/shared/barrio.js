"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var departamento_1 = require("../shared/departamento");
var Barrio = (function () {
    function Barrio() {
        this.Departamento = new departamento_1.Departamento();
    }
    return Barrio;
}());
exports.Barrio = Barrio;
//# sourceMappingURL=barrio.js.map