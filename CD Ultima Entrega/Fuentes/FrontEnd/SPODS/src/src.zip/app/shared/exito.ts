export class Exito {
    Descripcion: string;
}