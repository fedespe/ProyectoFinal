"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Carro = (function () {
    function Carro() {
    }
    return Carro;
}());
exports.Carro = Carro;
//# sourceMappingURL=carro.js.map